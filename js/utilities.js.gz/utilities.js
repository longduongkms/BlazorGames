﻿window.setTitle = (title) => {
    document.title = title + " - BlazorGames";
}